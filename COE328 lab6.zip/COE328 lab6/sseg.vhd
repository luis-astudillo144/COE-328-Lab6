LIBRARY ieee ;
USE ieee.std_logic_1164.all ;

ENTITY sseg IS
  PORT (
bcd   : IN STD_LOGIC_VECTOR(3 DOWNTO 0);
neg   : IN STD_LOGIC;
leds  : OUT STD_LOGIC_VECTOR(1 TO 7);
ledss : OUT STD_LOGIC_VECTOR(1 TO 7) --second LED
  );
END sseg;

ARCHITECTURE Behavior OF sseg IS
BEGIN
  PROCESS (bcd)
  BEGIN
	 IF (neg = '1') THEN
		ledss <= "1111110"; -- g turns on only if negative input
		ELSE 
		ledss <= "1111111";
		END IF;
		
    CASE bcd IS
      -- abcdefg
      WHEN "0000" => leds <= "0000001"; --0 0000001
      WHEN "0001" => leds <= "1001111"; --1 1001111
      WHEN "0010" => leds <= "0010010"; --2 0010010
      WHEN "0011" => leds <= "0000110"; --3 0000110
      WHEN "0100" => leds <= "1001100"; --4 1001100
      WHEN "0101" => leds <= "0100100"; --5 0100100
      WHEN "0110" => leds <= "0100000"; --6 0100000
      WHEN "0111" => leds <= "0001111"; --7 0001111
      WHEN "1000" => leds <= "0000000"; --8 0000000
      WHEN "1001" => leds <= "0001100"; --9 0001100

WHEN "1010" => leds <= "0001000"; -- A 10 0001000
WHEN "1011" => leds <= "1100000"; -- b 11 1100000
WHEN "1100" => leds <= "0110001"; -- C 12 0110001
WHEN "1101" => leds <= "1000010"; -- d 13 1000010
WHEN "1110" => leds <= "0110000"; -- E 14 0110000
WHEN "1111" => leds <= "0111000"; -- F 15 0111000
      WHEN OTHERS => leds <= "1111111"; -- nothing on 1111111
    END CASE;
  END PROCESS;
  
END Behavior;